WITH RankedGames AS (
    SELECT game_date, game_id, (home_score + away_score) AS total_runs,
           ROW_NUMBER() OVER (PARTITION BY game_date ORDER BY game_id) AS rank
    FROM Games
    WHERE (home_score + away_score) = (
        SELECT MAX(home_score + away_score)
        FROM Games g2
        WHERE g2.game_date = Games.game_date
    )
)
SELECT game_date, game_id, total_runs
FROM RankedGames
WHERE rank = 1
ORDER BY game_date;

  
