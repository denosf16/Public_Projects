SELECT t.team_name, 
       SUM(CASE WHEN g.home_team_id = t.team_id AND g.home_score > g.away_score THEN 1 
                WHEN g.away_team_id = t.team_id AND g.away_score > g.home_score THEN 1 ELSE 0 END) AS wins,
       SUM(CASE WHEN g.home_team_id = t.team_id AND g.home_score < g.away_score THEN 1 
                WHEN g.away_team_id = t.team_id AND g.away_score < g.home_score THEN 1 ELSE 0 END) AS losses
FROM Games g
JOIN Teams t ON g.home_team_id = t.team_id OR g.away_team_id = t.team_id
WHERE t.division = 'American League East'
GROUP BY t.team_name
ORDER BY wins DESC;
