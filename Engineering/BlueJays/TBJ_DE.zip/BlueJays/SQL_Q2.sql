SELECT AVG(
    CASE 
        WHEN g.home_team_id = t.team_id THEN CAST(l.home_runs AS FLOAT)
        WHEN g.away_team_id = t.team_id THEN CAST(l.away_runs AS FLOAT)
    END
) AS avg_blue_jays_8th_inning_runs
FROM Linescore l
JOIN Games g ON l.game_id = g.game_id
JOIN Teams t ON g.home_team_id = t.team_id OR g.away_team_id = t.team_id
WHERE t.team_name = 'Toronto Blue Jays' 
AND l.inning = 8;









