SELECT game_date, COUNT(*) AS g_played
FROM Games
GROUP BY game_date
ORDER BY game_date
